#ifndef __FONT_H
#define __FONT_H		

extern unsigned char  image[];
extern unsigned char  hanzi[];
extern unsigned char  asc2_1608[1520];
extern unsigned char 	asc2_2412[3430];
					  		 
#endif  


